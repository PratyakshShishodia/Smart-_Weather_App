/* ═══════════════════════════════════════════════════
   SkyCast – script.js
   OpenWeatherMap API integration + full UI logic
═══════════════════════════════════════════════════ */

'use strict';

// ────────────────────────────────────────────────────────────────────────────
// ⚠️  REPLACE with your own free key from https://openweathermap.org/api
// ────────────────────────────────────────────────────────────────────────────
const API_KEY = 'YOUR_API_KEY_HERE';
const BASE_URL = 'https://api.openweathermap.org/data/2.5';
const GEO_URL  = 'https://api.openweathermap.org/geo/1.0';
const AQI_URL  = 'https://api.openweathermap.org/data/2.5/air_pollution';

// ── State ────────────────────────────────────────
let isCelsius    = true;
let tempChart    = null;
let rawWeather   = null; // cache last fetched data
let rawForecast  = null;

// ── DOM refs ─────────────────────────────────────
const $ = id => document.getElementById(id);
const cityInput       = $('cityInput');
const searchBtn       = $('searchBtn');
const voiceBtn        = $('voiceBtn');
const locationBtn     = $('locationBtn');
const suggestions     = $('suggestions');
const recentSearches  = $('recentSearches');
const dashboard       = $('dashboard');
const loaderOverlay   = $('loaderOverlay');
const errorBanner     = $('errorBanner');
const errorMsg        = $('errorMsg');
const unitToggle      = $('unitToggle');
const themeToggle     = $('themeToggle');

// ── Init ─────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  renderRecentSearches();
  initBgCanvas();

  // Check for demo mode (no API key)
  if (API_KEY === 'YOUR_API_KEY_HERE') {
    loadDemoData();
  }
});

// ── Event Listeners ───────────────────────────────
searchBtn.addEventListener('click', handleSearch);
cityInput.addEventListener('keydown', e => { if (e.key === 'Enter') handleSearch(); });
cityInput.addEventListener('input',   debounce(handleAutocomplete, 350));
unitToggle.addEventListener('click',  toggleUnit);
themeToggle.addEventListener('click', toggleTheme);
locationBtn.addEventListener('click', fetchByLocation);
voiceBtn.addEventListener('click',    startVoiceSearch);
document.addEventListener('click', e => {
  if (!e.target.closest('.search-wrapper')) closeSuggestions();
});

// ── Search Handler ────────────────────────────────
async function handleSearch() {
  const city = cityInput.value.trim();
  if (!city) return;
  closeSuggestions();
  await fetchWeather(city);
}

// ── Fetch Weather ─────────────────────────────────
async function fetchWeather(city) {
  showLoader();
  hideError();
  try {
    // 1. Current weather
    const wRes = await fetch(`${BASE_URL}/weather?q=${encodeURIComponent(city)}&appid=${API_KEY}&units=metric`);
    if (!wRes.ok) throw new Error(wRes.status === 404 ? 'City not found.' : 'API error – please try later.');
    const weather = await wRes.json();

    // 2. 5-day / hourly forecast
    const fRes = await fetch(`${BASE_URL}/forecast?q=${encodeURIComponent(city)}&appid=${API_KEY}&units=metric`);
    const forecast = await fRes.json();

    // 3. AQI
    const { lat, lon } = weather.coord;
    const aRes = await fetch(`${AQI_URL}?lat=${lat}&lon=${lon}&appid=${API_KEY}`);
    const aqiData = await aRes.json();

    rawWeather  = weather;
    rawForecast = forecast;

    saveRecentSearch(city);
    renderAll(weather, forecast, aqiData);
    showDashboard();
  } catch (err) {
    showError(err.message || 'Something went wrong.');
  } finally {
    hideLoader();
  }
}

// ── Render All ────────────────────────────────────
function renderAll(weather, forecast, aqiData) {
  renderMainCard(weather);
  renderSideStats(weather);
  renderHourly(forecast);
  renderForecast(forecast);
  renderChart(forecast);
  renderAQI(aqiData);
  renderSunArc(weather);
  applyWeatherBackground(weather);
}

// ── Main Card ─────────────────────────────────────
function renderMainCard(w) {
  const t = convertTemp(w.main.temp);
  const fl = convertTemp(w.main.feels_like);
  const unit = isCelsius ? '°C' : '°F';

  $('cityName').textContent     = `${w.name}, ${w.sys.country}`;
  $('cityDate').textContent     = formatDate(new Date());
  $('temperature').textContent  = `${Math.round(t)}${unit}`;
  $('condition').textContent    = w.weather[0].description;
  $('feelsLike').textContent    = `Feels like ${Math.round(fl)}${unit}`;
  $('humidity').textContent     = `${w.main.humidity}%`;
  $('windSpeed').textContent    = `${(w.wind.speed * 3.6).toFixed(1)} km/h`;
  $('visibility').textContent   = `${(w.visibility / 1000).toFixed(1)} km`;
  $('animIcon').textContent     = getWeatherEmoji(w.weather[0].id, w.dt, w.sys.sunrise, w.sys.sunset);

  // Animate icon
  $('animIcon').style.animation = 'none';
  setTimeout(() => { $('animIcon').style.animation = ''; }, 20);
}

// ── Side Stats ────────────────────────────────────
function renderSideStats(w) {
  $('pressure').textContent = w.main.pressure;
  $('clouds').textContent   = w.clouds.all;
  const sr = formatTime(w.sys.sunrise, w.timezone);
  const ss = formatTime(w.sys.sunset,  w.timezone);
  $('sunrise').textContent  = sr;
  $('sunset').textContent   = ss;
  $('sunriseCard').textContent = sr;
  $('sunsetCard').textContent  = ss;
}

// ── Hourly Forecast ───────────────────────────────
function renderHourly(f) {
  const container = $('hourlyScroll');
  container.innerHTML = '';
  const slices = f.list.slice(0, 12); // next 36 hours (every 3h)
  slices.forEach((item, i) => {
    const time    = new Date(item.dt * 1000);
    const label   = i === 0 ? 'Now' : formatHour(time);
    const temp    = Math.round(convertTemp(item.main.temp));
    const icon    = getWeatherEmoji(item.weather[0].id);
    const rain    = item.pop !== undefined ? Math.round(item.pop * 100) : 0;
    const unit    = isCelsius ? '°C' : '°F';

    const el = document.createElement('div');
    el.className = `hourly-item${i === 0 ? ' now' : ''}`;
    el.style.animationDelay = `${i * 40}ms`;
    el.innerHTML = `
      <span class="hourly-time">${label}</span>
      <span class="hourly-icon">${icon}</span>
      <span class="hourly-temp">${temp}${unit}</span>
      ${rain > 10 ? `<span class="hourly-rain">💧 ${rain}%</span>` : ''}
    `;
    container.appendChild(el);
  });
}

// ── 5-Day Forecast ────────────────────────────────
function renderForecast(f) {
  const container = $('forecastRow');
  container.innerHTML = '';

  // Group by day
  const days = {};
  f.list.forEach(item => {
    const d = new Date(item.dt * 1000);
    const key = d.toDateString();
    if (!days[key]) days[key] = [];
    days[key].push(item);
  });

  const dayKeys = Object.keys(days).slice(0, 5);
  dayKeys.forEach((key, i) => {
    const items = days[key];
    const temps = items.map(x => x.main.temp);
    const hi    = Math.round(convertTemp(Math.max(...temps)));
    const lo    = Math.round(convertTemp(Math.min(...temps)));
    const mid   = items[Math.floor(items.length / 2)];
    const icon  = getWeatherEmoji(mid.weather[0].id);
    const cond  = mid.weather[0].description;
    const rain  = Math.round(Math.max(...items.map(x => x.pop || 0)) * 100);
    const unit  = isCelsius ? '°C' : '°F';
    const date  = new Date(mid.dt * 1000);
    const dayLbl = i === 0 ? 'Today' : date.toLocaleDateString('en', { weekday: 'short' });

    const card = document.createElement('div');
    card.className = 'card glass forecast-card';
    card.style.animationDelay = `${i * 80}ms`;
    card.innerHTML = `
      <span class="forecast-day">${dayLbl}</span>
      <span class="forecast-icon">${icon}</span>
      <div class="forecast-temps">
        <span class="f-hi">${hi}${unit}</span>
        <span class="f-lo">${lo}${unit}</span>
      </div>
      <span class="forecast-cond">${cond}</span>
      ${rain > 10 ? `<span class="forecast-rain">💧 ${rain}%</span>` : ''}
    `;
    container.appendChild(card);
  });
}

// ── Temperature Chart ─────────────────────────────
function renderChart(f) {
  const labels = [];
  const temps  = [];
  const feels  = [];

  f.list.slice(0, 8).forEach(item => {
    const d = new Date(item.dt * 1000);
    labels.push(formatHour(d));
    temps.push(Math.round(convertTemp(item.main.temp)));
    feels.push(Math.round(convertTemp(item.main.feels_like)));
  });

  const ctx = document.getElementById('tempChart').getContext('2d');
  if (tempChart) tempChart.destroy();

  const isDark = document.documentElement.getAttribute('data-theme') !== 'light';

  tempChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [
        {
          label: 'Temperature',
          data: temps,
          borderColor: '#4FC3F7',
          backgroundColor: 'rgba(79,195,247,0.12)',
          fill: true,
          tension: 0.45,
          pointBackgroundColor: '#4FC3F7',
          pointRadius: 4,
          pointHoverRadius: 7,
        },
        {
          label: 'Feels Like',
          data: feels,
          borderColor: '#FFD54F',
          backgroundColor: 'transparent',
          borderDash: [5, 4],
          tension: 0.45,
          pointBackgroundColor: '#FFD54F',
          pointRadius: 3,
          pointHoverRadius: 6,
        }
      ]
    },
    options: {
      responsive: true,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: {
          labels: {
            color: isDark ? 'rgba(240,244,255,0.55)' : 'rgba(13,21,38,0.6)',
            font: { family: 'DM Sans', size: 12 },
          }
        },
        tooltip: {
          backgroundColor: isDark ? 'rgba(13,21,38,0.9)' : 'rgba(255,255,255,0.95)',
          titleColor: isDark ? '#f0f4ff' : '#0d1526',
          bodyColor:  isDark ? 'rgba(240,244,255,0.7)' : 'rgba(13,21,38,0.6)',
          borderColor: 'rgba(79,195,247,0.3)',
          borderWidth: 1,
          callbacks: {
            label: ctx => ` ${ctx.dataset.label}: ${ctx.raw}${isCelsius ? '°C' : '°F'}`
          }
        }
      },
      scales: {
        x: {
          ticks: { color: isDark ? 'rgba(240,244,255,0.45)' : 'rgba(13,21,38,0.5)', font: { size: 11 } },
          grid:  { color: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)' }
        },
        y: {
          ticks: {
            color: isDark ? 'rgba(240,244,255,0.45)' : 'rgba(13,21,38,0.5)',
            font: { size: 11 },
            callback: v => `${v}${isCelsius ? '°C' : '°F'}`
          },
          grid:  { color: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)' }
        }
      }
    }
  });
}

// ── AQI ───────────────────────────────────────────
function renderAQI(data) {
  if (!data || !data.list || !data.list[0]) return;
  const aqi = data.list[0].main.aqi;
  const comp = data.list[0].components;

  const labels = ['–','Good','Fair','Moderate','Poor','Hazardous'];
  const colors  = ['–','#66BB6A','#FFF176','#FF8A65','#EF5350','#B71C1C'];
  const pct     = ((aqi - 1) / 4) * 100; // 1-5 scale

  $('aqiValue').textContent = aqi;
  $('aqiLabel').textContent = labels[aqi] || '–';
  $('aqiValue').style.color = colors[aqi] || '#fff';
  $('aqiFill').style.left   = `calc(${pct}% - 2px)`;

  // Components
  const compEl = $('aqiComponents');
  compEl.innerHTML = '';
  const shown = { pm2_5: 'PM2.5', pm10: 'PM10', no2: 'NO₂', o3: 'O₃', co: 'CO', so2: 'SO₂' };
  Object.entries(shown).forEach(([key, label]) => {
    const val = comp[key] !== undefined ? comp[key].toFixed(1) : '–';
    const el = document.createElement('div');
    el.className = 'aqi-comp';
    el.innerHTML = `<span class="aqi-comp-name">${label}</span><span class="aqi-comp-val">${val}</span>`;
    compEl.appendChild(el);
  });
}

// ── Sun Arc ───────────────────────────────────────
function renderSunArc(w) {
  const now     = Date.now() / 1000;
  const sunrise = w.sys.sunrise;
  const sunset  = w.sys.sunset;
  const srStr   = formatTime(sunrise, w.timezone);
  const ssStr   = formatTime(sunset,  w.timezone);

  $('sunriseLabel').textContent = srStr;
  $('sunsetLabel').textContent  = ssStr;

  // Compute position along arc 0→1
  const ratio = Math.min(Math.max((now - sunrise) / (sunset - sunrise), 0), 1);
  // Arc from (20,130) to (240,130) with apex at (130,10)
  const t = ratio;
  const ax=20, ay=130, bx=240, by=130, cx=130, cy=10;
  const qx = (1-t)*(1-t)*ax + 2*(1-t)*t*cx + t*t*bx;
  const qy = (1-t)*(1-t)*ay + 2*(1-t)*t*cy + t*t*by;

  const dot = $('sunDot');
  if (dot) {
    dot.setAttribute('cx', qx.toFixed(1));
    dot.setAttribute('cy', qy.toFixed(1));
  }
}

// ── Background ────────────────────────────────────
function applyWeatherBackground(w) {
  const id  = w.weather[0].id;
  const now = w.dt;
  const sr  = w.sys.sunrise;
  const ss  = w.sys.sunset;

  document.body.classList.remove('weather-clear-day','weather-rain','weather-snow','weather-thunderstorm');

  if      (id >= 200 && id < 300) document.body.classList.add('weather-thunderstorm');
  else if (id >= 300 && id < 600) document.body.classList.add('weather-rain');
  else if (id >= 600 && id < 700) document.body.classList.add('weather-snow');
  else if (id === 800 && now > sr && now < ss) document.body.classList.add('weather-clear-day');

  // Re-init canvas for new bg
  initBgCanvas(id, now > sr && now < ss);
}

// ── Unit Toggle ───────────────────────────────────
function toggleUnit() {
  isCelsius = !isCelsius;
  unitToggle.textContent = isCelsius ? '°C' : '°F';
  if (rawWeather && rawForecast) {
    renderMainCard(rawWeather);
    renderHourly(rawForecast);
    renderForecast(rawForecast);
    renderChart(rawForecast);
  }
}

function convertTemp(c) {
  return isCelsius ? c : (c * 9/5 + 32);
}

// ── Theme Toggle ──────────────────────────────────
function toggleTheme() {
  const html = document.documentElement;
  const isDark = html.getAttribute('data-theme') === 'dark';
  html.setAttribute('data-theme', isDark ? 'light' : 'dark');
  themeToggle.textContent = isDark ? '☀️' : '🌙';
  if (rawForecast) renderChart(rawForecast);
}

// ── Geolocation ───────────────────────────────────
function fetchByLocation() {
  if (!navigator.geolocation) return showError('Geolocation not supported.');
  navigator.geolocation.getCurrentPosition(
    async pos => {
      showLoader();
      hideError();
      try {
        const { latitude: lat, longitude: lon } = pos.coords;
        const r = await fetch(`${GEO_URL}/reverse?lat=${lat}&lon=${lon}&limit=1&appid=${API_KEY}`);
        const data = await r.json();
        if (!data.length) throw new Error('Location not found.');
        cityInput.value = data[0].name;
        await fetchWeather(data[0].name);
      } catch (e) {
        showError(e.message);
      } finally {
        hideLoader();
      }
    },
    () => showError('Location permission denied.')
  );
}

// ── Voice Search ──────────────────────────────────
function startVoiceSearch() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return showError('Voice search not supported in this browser.');
  const rec = new SR();
  rec.lang = 'en-US';
  rec.start();
  voiceBtn.classList.add('listening');
  rec.onresult = e => {
    cityInput.value = e.results[0][0].transcript;
    voiceBtn.classList.remove('listening');
    handleSearch();
  };
  rec.onerror = () => voiceBtn.classList.remove('listening');
  rec.onend   = () => voiceBtn.classList.remove('listening');
}

// ── Autocomplete ──────────────────────────────────
async function handleAutocomplete() {
  const q = cityInput.value.trim();
  if (q.length < 2) { closeSuggestions(); return; }
  try {
    const r = await fetch(`${GEO_URL}/direct?q=${encodeURIComponent(q)}&limit=5&appid=${API_KEY}`);
    const data = await r.json();
    renderSuggestions(data);
  } catch { /* silently ignore autocomplete failures */ }
}

function renderSuggestions(cities) {
  suggestions.innerHTML = '';
  if (!cities || !cities.length) { closeSuggestions(); return; }
  cities.forEach(c => {
    const li = document.createElement('li');
    li.innerHTML = `<span>📍</span> ${c.name}${c.state ? ', ' + c.state : ''}, ${c.country}`;
    li.addEventListener('click', () => {
      cityInput.value = c.name;
      closeSuggestions();
      fetchWeather(c.name);
    });
    suggestions.appendChild(li);
  });
  suggestions.classList.add('open');
}

function closeSuggestions() { suggestions.classList.remove('open'); }

// ── Recent Searches ───────────────────────────────
function saveRecentSearch(city) {
  let arr = getRecent();
  arr = [city, ...arr.filter(x => x.toLowerCase() !== city.toLowerCase())].slice(0, 6);
  localStorage.setItem('skycast_recent', JSON.stringify(arr));
  renderRecentSearches();
}

function getRecent() {
  try { return JSON.parse(localStorage.getItem('skycast_recent') || '[]'); }
  catch { return []; }
}

function renderRecentSearches() {
  const arr = getRecent();
  recentSearches.innerHTML = '';
  arr.forEach(city => {
    const pill = document.createElement('button');
    pill.className = 'recent-pill';
    pill.textContent = city;
    pill.addEventListener('click', () => {
      cityInput.value = city;
      fetchWeather(city);
    });
    recentSearches.appendChild(pill);
  });
}

// ── UI Helpers ────────────────────────────────────
function showLoader() { loaderOverlay.classList.add('active'); dashboard.classList.remove('visible'); }
function hideLoader() { loaderOverlay.classList.remove('active'); }
function showDashboard() { dashboard.classList.add('visible'); }
function showError(msg) { errorMsg.textContent = msg; errorBanner.classList.add('show'); }
function hideError() { errorBanner.classList.remove('show'); }

// ── Format Helpers ────────────────────────────────
function formatDate(d) {
  return d.toLocaleDateString('en', { weekday:'long', year:'numeric', month:'long', day:'numeric' });
}
function formatHour(d) {
  return d.toLocaleTimeString('en', { hour:'numeric', hour12: true });
}
function formatTime(unix, tzOffset) {
  // OWM timezone is offset in seconds from UTC
  const d = new Date((unix + (tzOffset || 0)) * 1000);
  return d.toUTCString().slice(17, 22); // HH:MM
}

// ── Weather Emoji Map ─────────────────────────────
function getWeatherEmoji(id, dt, sr, ss) {
  const isNight = dt && sr && ss ? (dt < sr || dt > ss) : false;
  if (id >= 200 && id < 300) return '⛈';
  if (id >= 300 && id < 400) return '🌦';
  if (id >= 500 && id < 600) {
    if (id < 502) return '🌧';
    return '🌧';
  }
  if (id >= 600 && id < 700) return id === 611 ? '🌨' : '❄️';
  if (id >= 700 && id < 800) return id === 741 ? '🌫' : '🌁';
  if (id === 800) return isNight ? '🌕' : '☀️';
  if (id === 801) return isNight ? '🌙' : '🌤';
  if (id === 802) return '⛅';
  if (id <= 804) return '☁️';
  return '🌡';
}

// ── Debounce ──────────────────────────────────────
function debounce(fn, ms) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), ms);
  };
}

// ── Background Canvas (stars / particles) ─────────
function initBgCanvas(weatherId = 0, isDay = false) {
  const canvas = $('bgCanvas');
  const ctx    = canvas.getContext('2d');
  let W, H, particles = [];
  let animId;

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  // Cancel previous loop
  if (window._bgAnimId) cancelAnimationFrame(window._bgAnimId);

  // Determine particle type
  const isRain   = weatherId >= 300 && weatherId < 600;
  const isSnow   = weatherId >= 600 && weatherId < 700;
  const isStorm  = weatherId >= 200 && weatherId < 300;
  const isStars  = !isRain && !isSnow;

  const COUNT = isRain ? 140 : isSnow ? 80 : 100;

  particles = Array.from({ length: COUNT }, () => createParticle(isRain, isSnow, isStars));

  function createParticle(rain, snow, stars) {
    if (rain) {
      return {
        x: Math.random() * 2000 - 500,
        y: Math.random() * window.innerHeight,
        len: 10 + Math.random() * 20,
        speed: 8 + Math.random() * 12,
        alpha: 0.3 + Math.random() * 0.5,
      };
    }
    if (snow) {
      return {
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        r: 1.5 + Math.random() * 3,
        speed: 0.5 + Math.random() * 1.5,
        drift: (Math.random() - 0.5) * 0.5,
        alpha: 0.4 + Math.random() * 0.6,
      };
    }
    // Stars
    return {
      x: Math.random() * window.innerWidth,
      y: Math.random() * window.innerHeight,
      r: 0.4 + Math.random() * 1.5,
      alpha: 0.1 + Math.random() * 0.7,
      twinkle: Math.random() * Math.PI * 2,
      speed: 0.004 + Math.random() * 0.008,
    };
  }

  function drawRain(p) {
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
    ctx.lineTo(p.x + p.len * 0.3, p.y + p.len);
    ctx.strokeStyle = `rgba(170,210,255,${p.alpha})`;
    ctx.lineWidth = 1;
    ctx.stroke();
    p.x += 2.5; p.y += p.speed;
    if (p.y > H + 40) { p.y = -20; p.x = Math.random() * (W + 500) - 250; }
  }

  function drawSnow(p) {
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(220,235,255,${p.alpha})`;
    ctx.fill();
    p.y += p.speed; p.x += p.drift;
    if (p.y > H + 10) { p.y = -5; p.x = Math.random() * W; }
  }

  function drawStar(p) {
    p.twinkle += p.speed;
    const a = p.alpha * (0.6 + 0.4 * Math.sin(p.twinkle));
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(200,220,255,${a})`;
    ctx.fill();
  }

  function loop() {
    ctx.clearRect(0, 0, W, H);
    particles.forEach(p => {
      if (isRain || isStorm) drawRain(p);
      else if (isSnow)       drawSnow(p);
      else                   drawStar(p);
    });
    window._bgAnimId = requestAnimationFrame(loop);
  }
  loop();
}

// ────────────────────────────────────────────────────────────────────────────
// DEMO DATA – shown when no API key is configured
// ────────────────────────────────────────────────────────────────────────────
function loadDemoData() {
  const now = Math.floor(Date.now() / 1000);
  const weather = {
    name: 'New Delhi',
    sys: { country: 'IN', sunrise: now - 7200, sunset: now + 5400 },
    coord: { lat: 28.61, lon: 77.20 },
    timezone: 19800,
    dt: now,
    main: { temp: 32, feels_like: 35, humidity: 55, pressure: 1005 },
    wind: { speed: 4.5 },
    visibility: 8000,
    clouds: { all: 20 },
    weather: [{ id: 801, description: 'few clouds' }],
  };

  const buildSlice = (offsetH, tempBase, id) => ({
    dt: now + offsetH * 3600,
    main: { temp: tempBase + Math.random() * 3 - 1, feels_like: tempBase + 2, humidity: 55 },
    weather: [{ id, description: 'few clouds' }],
    pop: Math.random() * 0.2,
  });

  const forecastList = [];
  for (let i = 0; i < 40; i++) {
    const h = i * 3;
    forecastList.push(buildSlice(h, 30 + Math.sin(i * 0.5) * 4, 800 + (i % 4)));
  }
  const forecast = { list: forecastList };

  const aqiData = {
    list: [{
      main: { aqi: 2 },
      components: { pm2_5: 18.2, pm10: 35.4, no2: 28.1, o3: 65.3, co: 412.5, so2: 12.0 },
    }]
  };

  rawWeather  = weather;
  rawForecast = forecast;
  renderAll(weather, forecast, aqiData);
  showDashboard();

  // Show a subtle "demo mode" pill
  const pill = document.createElement('div');
  pill.style.cssText = `position:fixed;bottom:1.5rem;right:1.5rem;z-index:999;padding:0.4rem 1rem;border-radius:50px;background:rgba(255,213,79,0.15);border:1px solid rgba(255,213,79,0.4);color:#FFD54F;font-size:0.78rem;font-weight:600;letter-spacing:1px;pointer-events:none;`;
  pill.textContent = '⚡ DEMO MODE – Add API key in script.js';
  document.body.appendChild(pill);
}
