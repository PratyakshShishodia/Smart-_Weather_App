# ☁ SkyCast – Smart Weather App

![SkyCast Preview](assets/preview.png)

> A modern, responsive weather forecast web application with live API integration, dynamic backgrounds, and a premium glassmorphism UI.

---

## 🌟 Features

| Feature | Description |
|---------|-------------|
| 🔍 **City Search** | Real-time city search with autocomplete suggestions |
| 📍 **Geolocation** | One-click current location weather |
| 🎙 **Voice Search** | Web Speech API voice input |
| 🌡 **Live Weather** | Temperature, humidity, wind, pressure, visibility |
| 📅 **5-Day Forecast** | Daily high/low with condition & rain chance |
| ⏱ **Hourly Forecast** | Next 36 hours, scrollable cards |
| 📈 **Temp Chart** | Chart.js 24-hour temperature trend |
| 🌬 **Air Quality Index** | AQI with component breakdown (PM2.5, NO₂, O₃ …) |
| 🌅 **Sun Arc** | Visual sunrise/sunset position indicator |
| 🌓 **Dark/Light Mode** | Smooth theme toggle |
| °C / °F **Unit Switch** | Instant unit conversion across all values |
| 🕑 **Recent Searches** | LocalStorage-persisted search history pills |
| 🎨 **Dynamic Backgrounds** | Canvas-animated stars, rain, or snow per weather |

---

## 🚀 Quick Start

### 1. Get a Free API Key

Go to [openweathermap.org](https://openweathermap.org/api) → Sign up (free) → Copy your key.

### 2. Add the Key

Open `script.js` and replace the placeholder on line 10:

```js
const API_KEY = 'YOUR_API_KEY_HERE';  // ← paste your key here
```

### 3. Open the App

```bash
# Option A – just open in browser
open index.html

# Option B – serve locally (recommended to avoid CORS)
npx serve .
# or
python -m http.server 8080
```

---

## 📁 Project Structure

```
skycast/
├── index.html      # App markup & layout
├── style.css       # Glassmorphism design system + responsive styles
├── script.js       # Weather API logic, rendering, Canvas bg
├── assets/
│   └── preview.png # Screenshot for README
└── README.md
```

---

## 🛠 Tech Stack

- **HTML5** – Semantic markup
- **CSS3** – Custom properties, glassmorphism, CSS animations, grid/flexbox
- **JavaScript (ES2020)** – Modules, async/await, Web APIs
- **OpenWeatherMap API** – Current weather, forecast, geocoding, AQI
- **Chart.js v4** – Temperature trend visualisation
- **Web Speech API** – Voice search (Chrome/Edge)
- **Canvas API** – Animated star/rain/snow backgrounds

---

## 📡 API Endpoints Used

| Endpoint | Purpose |
|----------|---------|
| `/data/2.5/weather` | Current conditions |
| `/data/2.5/forecast` | 5-day / 3-hourly forecast |
| `/data/2.5/air_pollution` | AQI + pollutant components |
| `/geo/1.0/direct` | City → coordinates (autocomplete) |
| `/geo/1.0/reverse` | Coordinates → city name |

---

## 📸 Screenshots

| Dark Mode | Light Mode |
|-----------|------------|
| *(dark screenshot)* | *(light screenshot)* |

---

## 🤝 Contributing

Pull requests are welcome! For major changes, please open an issue first.

---

## 📝 License

MIT © 2025

---

## 👨‍💼 Resume Description

> *"Developed a responsive Weather Forecast Application — **SkyCast** — using Vanilla JavaScript, CSS3, and the OpenWeatherMap REST API. Implemented real-time city search with geolocation and voice input, a 5-day forecast, hourly chart (Chart.js), Air Quality Index visualisation, Canvas-animated dynamic backgrounds, dark/light mode, °C/°F toggle, and LocalStorage-based recent search history. Deployed as a production-grade single-page app with glassmorphism UI and mobile-first responsive design."*
